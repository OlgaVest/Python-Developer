# projects/decorators.py
from functools import wraps
from django.contrib.auth import REDIRECT_FIELD_NAME
from django.contrib.auth.decorators import user_passes_test
from django.shortcuts import redirect
from django.urls import reverse


def role_required(allowed_roles):
    """
    Декоратор для проверки роли пользователя.
    allowed_roles: список допустимых ролей, например, ['admin', 'manager']
    """

    def decorator(view_func):
        @wraps(view_func)
        def _wrapped_view(request, *args, **kwargs):
            # Проверяем, аутентифицирован ли пользователь
            if not request.user.is_authenticated:
                # Если нет, перенаправляем на страницу входа
                # reverse('login') генерирует URL для маршрута 'login'
                return redirect('{}?next={}'.format(reverse('login'), request.path))

            # Проверяем, есть ли роль пользователя в списке разрешенных
            if request.user.role in allowed_roles:
                # Если роль подходит, вызываем оригинальное представление
                return view_func(request, *args, **kwargs)
            else:
                # Если роль не подходит, перенаправляем, например, на главную
                # или можно вернуть 403 Forbidden
                return redirect('projects:home')
                # Альтернатива: from django.http import HttpResponseForbidden
                # return HttpResponseForbidden("Доступ запрещен. Недостаточно прав.")

        return _wrapped_view

    return decorator


# Можно создать отдельные декораторы для каждой роли для удобства
def admin_required(view_func):
    return role_required(['admin'])(view_func)


def manager_required(view_func):
    return role_required(['admin', 'manager'])(view_func)  # Админ тоже может


def user_required(view_func):
    return role_required(['admin', 'manager', 'user'])(view_func)  # Все могут
