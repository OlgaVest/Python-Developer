from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser
from .models import CustomUser, Project, Task


class CustomUserCreationForm(UserCreationForm):
    """
    Форма для создания нового пользователя с выбором роли.
    Наследуется от стандартной формы UserCreationForm.
    """
    # Можно скрыть поле роли, если не хотим, чтобы пользователь сам её выбирал при регистрации
    # role = forms.ChoiceField(choices=CustomUser.ROLE_CHOICES, initial='user')

    class Meta(UserCreationForm.Meta):
        model = CustomUser
        fields = UserCreationForm.Meta.fields + ('role',) # Добавляем поле role
        # Если хотите скрыть роль, уберите 'role' из fields и задайте initial в __init__

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Делаем поле роли необязательным или скрываем его
        # self.fields['role'].required = False
        # Или полностью скрываем:
        # if 'role' in self.fields:
        #     self.fields['role'].widget = forms.HiddenInput()
        #     self.fields['role'].initial = 'user' # Устанавливаем значение по умолчанию

        # Пример: Скрыть поле роли и установить значение по умолчанию
        if 'role' in self.fields:
            self.fields['role'].widget = forms.HiddenInput()
            self.fields['role'].initial = 'user'

class ProjectForm(forms.ModelForm):
    """
    Форма для создания и редактирования проекта.
    """
    class Meta:
        model = Project
        fields = ['name', 'description', 'manager']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
            'manager': forms.Select(attrs={'class': 'form-control'}),
        }
        # Можно добавить help_text или labels, если нужно
        # labels = {'name': 'Название проекта', ...}
        # help_texts = {'description': 'Краткое описание проекта', ...}

class TaskForm(forms.ModelForm):
    """
    Форма для создания и редактирования задачи.
    """
    class Meta:
        model = Task
        # Не включаем 'completed_at' и 'created_at', 'updated_at' - они управляются автоматически
        fields = ['title', 'description', 'project', 'assigned_to', 'status']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
            'project': forms.Select(attrs={'class': 'form-control'}),
            'assigned_to': forms.Select(attrs={'class': 'form-control'}),
            'status': forms.Select(attrs={'class': 'form-control'}),
        }
