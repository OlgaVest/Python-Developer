from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login
from django.contrib import messages
from django.utils import timezone
from .forms import CustomUserCreationForm, ProjectForm, TaskForm
from .decorators import admin_required
from .models import Project, Task
from django.contrib.auth.decorators import login_required
from .decorators import admin_required, manager_required, user_required
from django.db.models import ProtectedError

# Применяем декоратор: доступ только для администраторов
#@admin_required
def home(request):
    return render(request, 'home.html')

def register(request):
    """
    Представление для регистрации нового пользователя.
    """
    # Если запрос типа POST, значит, пользователь отправил данные формы
    if request.method == 'POST':
        # Создаем экземпляр формы, заполняя её данными из запроса
        form = CustomUserCreationForm(request.POST)
        # Проверяем, корректны ли данные в форме
        if form.is_valid():
            # Сохраняем нового пользователя в базе данных
            user = form.save()
            # Автоматически аутентифицируем (логиним) пользователя после регистрации
            login(request, user)
            # Добавляем сообщение об успешной регистрации
            messages.success(request, 'Вы успешно зарегистрировались!')
            # Перенаправляем пользователя на главную страницу (или любую другую)
            return redirect('projects:home')  # Исправлено на projects:home. Здесь 'home' - это имя URL-шаблона главной страницы, его нужно будет создать
        else:
            # Если форма невалидна, она автоматически отрендерится с ошибками
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        # Если запрос типа GET, значит, пользователь просто зашел на страницу
        # Создаем пустую форму для отображения
        form = CustomUserCreationForm()

    # Отправляем форму в шаблон для отображения
    return render(request, 'registration/register.html', {'form': form})

@manager_required
def project_list(request):
    """
    Представление для отображения списка проектов.
    Доступно только авторизованным пользователям.
    """
    # Получаем все проекты из базы данных
    projects = Project.objects.all().select_related('manager') # select_related для оптимизации
    # Передаем их в шаблон
    return render(request, 'projects/project_list.html', {'projects': projects})


@user_required
def task_list(request):
    """
    Представление для отображения списка задач.
    Доступно только авторизованным пользователям.
    """
    # Получаем все задачи из базы данных
    tasks = Task.objects.all().select_related('project', 'assigned_to') # select_related для оптимизации
    # Передаем их в шаблон
    return render(request, 'projects/task_list.html', {'tasks': tasks})


@manager_required  # Только менеджеры и админы
def project_create(request):
    """
    Представление для создания нового проекта.
    Доступно менеджерам и администраторам.
    """
    if request.method == 'POST':
        # Если запрос типа POST, обрабатываем форму
        form = ProjectForm(request.POST)
        if form.is_valid():
            # Если данные корректны, сохраняем проект
            project = form.save()
            # Добавляем сообщение об успехе
            messages.success(request, f'Проект "{project.name}" успешно создан.')
            # Перенаправляем на список проектов
            return redirect('projects:project_list')
        else:
            # Если форма невалидна, она будет отрендерена с ошибками
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        # Если запрос типа GET, создаем пустую форму
        form = ProjectForm()

    # Рендерим шаблон с формой
    return render(request, 'projects/project_form.html', {'form': form, 'action': 'Создать'})


@manager_required  # Только менеджеры и админы
def task_create(request):
    """
    Представление для создания новой задачи.
    Доступно менеджерам и администраторам.
    """
    if request.method == 'POST':
        # Если запрос типа POST, обрабатываем форму
        form = TaskForm(request.POST)
        if form.is_valid():
            # Если данные корректны, сохраняем задачу
            task = form.save()
            # Добавляем сообщение об успехе
            messages.success(request, f'Задача "{task.title}" успешно создана.')
            # Перенаправляем на список задач
            return redirect('projects:task_list')
        else:
            # Если форма невалидна, она будет отрендерена с ошибками
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        # Если запрос типа GET, создаем пустую форму
        form = TaskForm()

    # Рендерим шаблон с формой
    return render(request, 'projects/task_form.html', {'form': form, 'action': 'Создать'})


@manager_required  # Только менеджеры и админы
def project_update(request, project_id):
    """
    Представление для редактирования существующего проекта.
    Доступно менеджерам и администраторам.
    """
    # Получаем проект по ID или возвращаем 404, если не найден
    project = get_object_or_404(Project, id=project_id)

    if request.method == 'POST':
        # Если запрос типа POST, обрабатываем форму, заполняя её данными из запроса И экземпляра проекта
        form = ProjectForm(request.POST, instance=project)
        if form.is_valid():
            # Если данные корректны, сохраняем изменения в проекте
            updated_project = form.save()
            # Добавляем сообщение об успехе
            messages.success(request, f'Проект "{updated_project.name}" успешно обновлён.')
            # Перенаправляем на список проектов
            return redirect('projects:project_list')
        else:
            # Если форма невалидна, она будет отрендерена с ошибками
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        # Если запрос типа GET, создаем форму, заполняя её текущими данными проекта
        form = ProjectForm(instance=project)

    # Рендерим шаблон с формой
    return render(request, 'projects/project_form.html', {'form': form, 'action': 'Редактировать', 'project': project})


@manager_required  # Только менеджеры и админы
def task_update(request, task_id):
    """
    Представление для редактирования существующей задачи.
    Доступно менеджерам и администраторам.
    """
    # Получаем задачу по ID или возвращаем 404, если не найдена
    task = get_object_or_404(Task, id=task_id)

    if request.method == 'POST':
        # Если запрос типа POST, обрабатываем форму, заполняя её данными из запроса И экземпляра задачи
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            # Если данные корректны, сохраняем изменения в задаче
            updated_task = form.save()
            # Добавляем сообщение об успехе
            messages.success(request, f'Задача "{updated_task.title}" успешно обновлена.')
            # Перенаправляем на список задач
            return redirect('projects:task_list')
        else:
            # Если форма невалидна, она будет отрендерена с ошибками
            messages.error(request, 'Пожалуйста, исправьте ошибки в форме.')
    else:
        # Если запрос типа GET, создаем форму, заполняя её текущими данными задачи
        form = TaskForm(instance=task)


@admin_required # Только администраторы
def project_delete(request, project_id):
    """
    Представление для удаления существующего проекта.
    Доступно только администраторам.
    """
    # Получаем проект по ID или возвращаем 404, если не найден
    project = get_object_or_404(Project, id=project_id)

    if request.method == 'POST':
        # Если запрос типа POST, значит, пользователь подтвердил удаление
        try:
            project_name = project.name # Сохраняем имя для сообщения
            project.delete()
            # Добавляем сообщение об успехе
            messages.success(request, f'Проект "{project_name}" успешно удалён.')
        except ProtectedError:
            # Если на проект ссылаются другие объекты (например, задачи), нельзя его удалить
            messages.error(request, f'Невозможно удалить проект "{project.name}", так как на него ссылаются существующие задачи.')
        # Перенаправляем на список проектов
        return redirect('projects:project_list')
    else:
        # Если запрос типа GET, показываем страницу подтверждения удаления
        return render(request, 'projects/project_confirm_delete.html', {'project': project})

@manager_required # Менеджеры и администраторы
def task_delete(request, task_id):
    """
    Представление для удаления существующей задачи.
    Доступно менеджерам и администраторам.
    """
    # Получаем задачу по ID или возвращаем 404, если не найдена
    task = get_object_or_404(Task, id=task_id)

    if request.method == 'POST':
        # Если запрос типа POST, значит, пользователь подтвердил удаление
        try:
            task_title = task.title # Сохраняем заголовок для сообщения
            task.delete()
            # Добавляем сообщение об успехе
            messages.success(request, f'Задача "{task_title}" успешно удалена.')
        except ProtectedError:
            # На случай, если задачу невозможно удалить (маловероятно, но обработаем)
            messages.error(request, f'Невозможно удалить задачу "{task.title}".')
        # Перенаправляем на список задач
        return redirect('projects:task_list')
    else:
        # Если запрос типа GET, показываем страницу подтверждения удаления
        return render(request, 'projects/task_confirm_delete.html', {'task': task})


@login_required # Доступно любому авторизованному пользователю
def task_complete(request, task_id):
    """
    Представление для отметки задачи как завершённой.
    Доступно пользователю, которому назначена задача.
    """
    # Получаем задачу по ID или возвращаем 404, если не найдена
    task = get_object_or_404(Task, id=task_id)

    # Проверяем, назначена ли задача текущему пользователю
    if task.assigned_to != request.user:
        # Если нет, запрещаем доступ
        raise PermissionDenied("Вы можете завершить только задачи, назначенные вам.")
        # Это приведет к отображению страницы 403 Forbidden

    # Проверяем, не завершена ли задача уже
    if task.status == 'done':
        messages.info(request, f'Задача "{task.title}" уже завершена.')
    else:
        # Если задача назначена пользователю и не завершена, обновляем её
        task.status = 'done'
        task.completed_at = timezone.now() # Заполняем дату завершения
        task.save()
        # Добавляем сообщение об успехе
        messages.success(request, f'Задача "{task.title}" отмечена как завершённая.')

    # Перенаправляем на список задач
    return redirect('projects:task_list')
