# projects/urls.py
from django.urls import path
from . import views

# Пространство имён приложения. Полезно, если в проекте несколько приложений
# с одинаковыми именами маршрутов.
app_name = 'projects'

urlpatterns = [
    # Маршрут для регистрации. Пока у нас нет главной страницы 'home',
    # мы временно перенаправим на список проектов (который создадим позже)
    # или на админку. Для начала сделаем просто путь к регистрации.
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('projects/', views.project_list, name='project_list'),
    path('tasks/', views.task_list, name='task_list'),
    path('projects/create/', views.project_create, name='project_create'),
    path('tasks/create/', views.task_create, name='task_create'),
    path('projects/<int:project_id>/update/', views.project_update, name='project_update'),
    path('tasks/<int:task_id>/update/', views.task_update, name='task_update'),
    path('projects/<int:project_id>/delete/', views.project_delete, name='project_delete'),
    path('tasks/<int:task_id>/delete/', views.task_delete, name='task_delete'),
    path('tasks/<int:task_id>/complete/', views.task_complete, name='task_complete'),
    # Добавим заглушку для главной страницы, чтобы redirect в views.py работал
    # Или создадим её позже. Пока пусть будет так:
    # path('', views.some_home_view, name='home'), # Закомментировано, так как представления ещё нет
]
