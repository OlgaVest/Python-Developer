from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser
from .models import CustomUser, Project, Task


@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    # Поля, которые будут отображаться в списке пользователей
    list_display = ('username', 'email', 'first_name', 'last_name', 'role', 'is_staff')

    # Поля, по которым можно фильтровать список пользователей
    list_filter = ('role', 'is_staff', 'is_superuser', 'is_active')

    # Поля, по которым можно осуществлять поиск
    search_fields = ('username', 'email', 'first_name', 'last_name')

    # Группировка полей в форме редактирования пользователя
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Персональная информация', {'fields': ('first_name', 'last_name', 'email')}),
        ('Разрешения', {
            'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions'),
        }),
        ('Важные даты', {'fields': ('last_login', 'date_joined')}),
        ('Роль', {'fields': ('role',)}),  # Добавляем наше поле role
    )

    # Группировка полей в форме создания пользователя
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'role', 'password1', 'password2'),  # Добавляем role в форму создания
        }),
    )

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('name', 'manager', 'created_at')
    list_filter = ('manager', 'created_at')
    search_fields = ('name', 'description')
    raw_id_fields = ('manager',) # Для удобства выбора менеджера в больших списках

@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ('title', 'project', 'assigned_to', 'status', 'created_at')
    list_filter = ('project', 'assigned_to', 'status', 'created_at')
    search_fields = ('title', 'description')
    raw_id_fields = ('project', 'assigned_to') # Для удобства выбора проекта/пользователя