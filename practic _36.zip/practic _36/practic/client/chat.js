document.addEventListener("DOMContentLoaded", () => {
    let username = null;
    let ws = null;

    const loginContainer = document.getElementById("login-container");
    const chatContainer = document.getElementById("chat-container");
    const usernameInput = document.getElementById("username-input");
    const loginButton = document.getElementById("login-button");

    const chatWindow = document.getElementById("chat-window");
    const messageInput = document.getElementById("message-input");
    const sendButton = document.getElementById("send-button");

    // Входим в чат по клику на кнопку "Войти"
    loginButton.addEventListener("click", () => {
        username = usernameInput.value.trim();
        if (username !== "") {
            // Скрываем форму логина и показываем чат
            loginContainer.style.display = "none";
            chatContainer.style.display = "flex";
            initializeWebSocket();
        }
    });

    // Инициализация WebSocket-подключения
    function initializeWebSocket() {
        ws = new WebSocket("ws://localhost:8765");

        ws.onopen = () => {
            console.log("Подключение к серверу установлено");
            appendMessage("Система: Подключено к чату", "system");
        };

        ws.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                if (data.type === 'history') {
                    // Обработка истории сообщений
                    displayHistory(data.messages);
                } else {
                    // Обычное сообщение
                    appendMessage(event.data);
                }
            } catch (e) {
                // Не JSON - обычное текстовое сообщение
                appendMessage(event.data);
            }
        };

        ws.onclose = () => {
            console.log("Соединение с сервером закрыто");
            appendMessage("Система: Отключено от чата", "system");
            // Попытка переподключения через 3 секунды
            setTimeout(() => {
                if (loginContainer.style.display === "none") { // Только если мы в чате
                    initializeWebSocket();
                }
            }, 3000);
        };

        ws.onerror = (error) => {
            console.error("Ошибка WebSocket:", error);
            appendMessage("Ошибка подключения к серверу", "system");
        };
    }

    // Отправка сообщения по кнопке "Отправить"
    sendButton.addEventListener("click", sendMessage);

    // Отправка по Enter
    messageInput.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
            sendMessage();
        }
    });

    // Формируем сообщение с именем пользователя и отправляем
    function sendMessage() {
        const text = messageInput.value.trim();
        if (text !== "" && ws && ws.readyState === WebSocket.OPEN) {
            const fullMessage = `${username}: ${text}`;
            ws.send(fullMessage);
            messageInput.value = "";
        } else if (!ws || ws.readyState !== WebSocket.OPEN) {
            appendMessage("Ошибка: Нет подключения к серверу", "system");
        }
    }

    // Добавляем новое сообщение в окно чата и прокручиваем вниз
    function appendMessage(message, type = "normal") {
        const messageElem = document.createElement("div");
        messageElem.className = `message ${type}`;

        // Добавляем временную метку
        const timestamp = new Date().toLocaleTimeString();
        messageElem.innerHTML = `<span class="timestamp">[${timestamp}]</span> ${message}`;

        chatWindow.appendChild(messageElem);

        // Прокручиваем окно к последнему сообщению
        chatWindow.scrollTop = chatWindow.scrollHeight;
    }

    // Отображение истории сообщений
    function displayHistory(historyMessages) {
        if (historyMessages && historyMessages.length > 0) {
            appendMessage("=== История сообщений ===", "system");
            historyMessages.forEach(historyMessage => {
                const timestamp = new Date(historyMessage.timestamp).toLocaleTimeString();
                const messageElem = document.createElement("div");
                messageElem.className = "message history";
                messageElem.innerHTML = `<span class="timestamp">[${timestamp}]</span> ${historyMessage.message}`;
                chatWindow.appendChild(messageElem);
            });
            appendMessage("=== Конец истории ===", "system");
            // Прокручиваем окно к последнему сообщению
            chatWindow.scrollTop = chatWindow.scrollHeight;
        }
    }
});