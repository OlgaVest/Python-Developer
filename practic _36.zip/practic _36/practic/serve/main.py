import asyncio
import websockets
import logging
import json
from datetime import datetime
import os

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s: %(message)s')
logger = logging.getLogger(__name__)

# Множество для хранения активных WebSocket-подключений
connected_clients = set()

# Файл для хранения истории сообщений
HISTORY_FILE = "chat_history.txt"
# Максимальное количество сообщений в истории
MAX_HISTORY_MESSAGES = 20

def load_history():
    """
    Загружает историю сообщений из файла.
    Возвращает список сообщений или пустой список, если файл не существует.
    """
    try:
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
                history = json.load(f)
                logger.info(f"Загружено {len(history)} сообщений из истории")
                return history
        else:
            logger.info("Файл истории не найден, создается новая история")
            return []
    except Exception as e:
        logger.error(f"Ошибка при загрузке истории: {e}")
        return []

def save_history(history):
    """
    Сохраняет историю сообщений в файл.
    """
    try:
        with open(HISTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False, indent=2)
        logger.info(f"Сохранено {len(history)} сообщений в историю")
    except Exception as e:
        logger.error(f"Ошибка при сохранении истории: {e}")

def add_message_to_history(message, history):
    """
    Добавляет новое сообщение в историю и ограничивает размер истории.
    """
    # Добавляем временную метку к сообщению
    timestamped_message = {
        "timestamp": datetime.now().isoformat(),
        "message": message
    }
    
    history.append(timestamped_message)
    
    # Ограничиваем размер истории
    if len(history) > MAX_HISTORY_MESSAGES:
        history = history[-MAX_HISTORY_MESSAGES:]
    
    return history

# Загружаем историю при запуске сервера
chat_history = load_history()

async def handle_connection(websocket):
    """
    Обработчик нового подключения.
    Регистрирует клиента, принимает входящие сообщения и транслирует их всем подключенным клиентам.
    """
    global chat_history

    connected_clients.add(websocket)
    logger.info(f"Новое подключение: {websocket.remote_address}")
    
    # Отправляем историю сообщений новому клиенту
    try:
        if chat_history:
            # Отправляем историю как одно сообщение в формате JSON
            history_message = {
                "type": "history",
                "messages": chat_history
            }
            await websocket.send(json.dumps(history_message, ensure_ascii=False))
            logger.info(f"Отправлена история из {len(chat_history)} сообщений клиенту {websocket.remote_address}")
    except Exception as e:
        logger.error(f"Ошибка при отправке истории клиенту {websocket.remote_address}: {e}")
    
    try:
        async for message in websocket:
            logger.info(f"Получено сообщение: {message} от {websocket.remote_address}")
            
            # Добавляем сообщение в историю
            #global chat_history
            chat_history = add_message_to_history(message, chat_history)
            
            # Сохраняем обновленную историю
            save_history(chat_history)
            
            # Транслируем сообщение всем клиентам
            await broadcast(message)
    except websockets.exceptions.ConnectionClosed as e:
        logger.warning(f"Соединение с клиентом {websocket.remote_address} закрыто: {e}")
    finally:
        connected_clients.remove(websocket)
        logger.info(f"Клиент {websocket.remote_address} отключился")

async def broadcast(message):
    """
    Транслирует полученное сообщение всем подключенным клиентам.
    """
    if connected_clients:
        # Отправляем сообщение всем клиентам, используя asyncio.gather
        await asyncio.gather(*(client.send(message) for client in connected_clients), return_exceptions=True)

async def main():
    # Запуск WebSocket-сервера на localhost:8765
    server = await websockets.serve(handle_connection, "localhost", 8765)
    logger.info("WebSocket сервер запущен на ws://localhost:8765")
    logger.info(f"История сообщений сохраняется в: {HISTORY_FILE}")
    logger.info(f"Максимальное количество сообщений в истории: {MAX_HISTORY_MESSAGES}")
    await server.wait_closed()

if __name__ == "__main__":
    asyncio.run(main())