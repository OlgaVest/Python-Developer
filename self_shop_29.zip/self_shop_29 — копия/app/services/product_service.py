# app/services/product_service.py
from sqlalchemy.orm import Session
from app import models, schemas
from typing import List, Optional


def get_product(db: Session, product_id: int) -> Optional[models.Product]:
    return db.query(models.Product).filter(models.Product.id == product_id).first()


def get_product_by_name(db: Session, name: str) -> Optional[models.Product]:
    return db.query(models.Product).filter(models.Product.name == name).first()


def get_products(db: Session, skip: int = 0, limit: int = 100) -> List[models.Product]:
    return db.query(models.Product).offset(skip).limit(limit).all()


def create_product(db: Session, product: schemas.ProductCreate) -> models.Product:
    # Проверяем, существует ли уже товар с таким названием
    db_product = get_product_by_name(db, product.name)
    if db_product:
        raise ValueError("Product with this name already exists")

    db_product = models.Product(
        name=product.name,
        description=product.description,
        price=product.price,
        category_id=product.category_id,
        stock=product.stock,
        image_url=str(product.image_url) if product.image_url else None
    )
    db.add(db_product)
    db.commit()
    db.refresh(db_product)
    return db_product


def update_product(db: Session, product_id: int, product_update: schemas.ProductUpdate) -> Optional[models.Product]:
    db_product = get_product(db, product_id)
    if db_product is None:
        return None

    update_data = product_update.dict(exclude_unset=True)
    # Преобразуем HttpUrl в строку если есть
    if 'image_url' in update_data and update_data['image_url'] is not None:
        update_data['image_url'] = str(update_data['image_url'])

    for key, value in update_data.items():
        setattr(db_product, key, value)

    db.commit()
    db.refresh(db_product)
    return db_product


def delete_product(db: Session, product_id: int) -> bool:
    db_product = get_product(db, product_id)
    if db_product is None:
        return False

    db.delete(db_product)
    db.commit()
    return True


