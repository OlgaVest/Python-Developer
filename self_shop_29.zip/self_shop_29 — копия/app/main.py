# main.py
from fastapi import FastAPI
from .database import Base, engine
from . import models
# Роуты
from .routes import admin, auth, frontend, orders, products

# Создаём таблицы
Base.metadata.create_all(bind=engine)

# Создаём приложение
app = FastAPI(
    title="Self Shop API",
    description="API для интернет-магазина с валидацией товаров",
    version="1.0.0"
)

# Подключаем свои роуты
app.include_router(admin.router)
app.include_router(auth.router, prefix="/auth", tags=["auth"])
app.include_router(frontend.router, tags=["frontend"])
app.include_router(orders.router, prefix="/orders", tags=["orders"])
app.include_router(products.router)

# Тестовый эндпоинт
@app.get("/")
async def root():
    return {"message": "Добро пожаловать в Self Shop API!"}

# Эндпоинт для проверки здоровья приложения
@app.get("/health")
async def health_check():
    return {"status": "healthy"}
