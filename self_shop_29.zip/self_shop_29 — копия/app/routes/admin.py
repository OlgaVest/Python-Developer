# app/routes/admin.py
from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from typing import List
from .. import schemas
from ..database import SessionLocal
from ..services import product_service

router = APIRouter(prefix="/admin-panel", tags=["admin-panel"])

# Получаем сессию базы данных как зависимость
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Создание товара
@router.post("/products", response_model=schemas.Product)
async def create_product(product: schemas.ProductCreate, db: Session = Depends(get_db)):
    try:
        db_product = product_service.create_product(db, product)
        return db_product
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

# Получение товара по ID
@router.get("/products/{product_id}", response_model=schemas.Product)
async def read_product(product_id: int, db: Session = Depends(get_db)):
    db_product = product_service.get_product(db, product_id)
    if db_product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    return db_product

# Обновление товара
@router.put("/products/{product_id}", response_model=schemas.Product)
async def update_product(product_id: int, product: schemas.ProductUpdate, db: Session = Depends(get_db)):
    db_product = product_service.update_product(db, product_id, product)
    if db_product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    return db_product

# Удаление товара
@router.delete("/products/{product_id}")
async def delete_product(product_id: int, db: Session = Depends(get_db)):
    success = product_service.delete_product(db, product_id)
    if not success:
        raise HTTPException(status_code=404, detail="Product not found")
    return {"message": "Product deleted successfully"}

# Получение всех товаров (по желанию)
@router.get("/products", response_model=List[schemas.Product])
async def read_products(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    db_products = product_service.get_products(db, skip=skip, limit=limit)
    return db_products
