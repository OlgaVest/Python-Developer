# app/routes/orders.py
from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from typing import List
from .. import schemas, models
from ..database import SessionLocal

router = APIRouter(prefix="/orders", tags=["orders"])


# Получаем сессию базы данных как зависимость
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Создание заказа
@router.post("/", response_model=schemas.Order)
async def create_order(order: schemas.OrderCreate, db: Session = Depends(get_db)):
    # Проверяем, существует ли пользователь
    db_user = db.query(models.User).filter(models.User.id == order.user_id).first()
    if not db_user:
        raise HTTPException(status_code=404, detail="User not found")

    # Создаем заказ
    db_order = models.Order(
        user_id=order.user_id,
        total_price=0  # Будет рассчитан позже
    )
    db.add(db_order)
    db.commit()
    db.refresh(db_order)

    # Создаем элементы заказа (если есть)
    total_price = 0
    for item in order.items:
        # Проверяем, существует ли продукт
        db_product = db.query(models.Product).filter(models.Product.id == item.product_id).first()
        if not db_product:
            raise HTTPException(status_code=404, detail=f"Product {item.product_id} not found")

        # Создаем элемент заказа
        db_order_item = models.OrderItem(
            order_id=db_order.id,
            product_id=item.product_id,
            quantity=item.quantity
        )
        db.add(db_order_item)
        total_price += db_product.price * item.quantity

    # Обновляем общую сумму заказа
    db_order.total_price = total_price
    db.commit()
    db.refresh(db_order)

    return db_order


# Получение всех заказов
@router.get("/", response_model=List[schemas.Order])
async def read_orders(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    db_orders = db.query(models.Order).offset(skip).limit(limit).all()
    return db_orders


# Получение заказа по ID
@router.get("/{order_id}", response_model=schemas.Order)
async def read_order(order_id: int, db: Session = Depends(get_db)):
    db_order = db.query(models.Order).filter(models.Order.id == order_id).first()
    if db_order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    return db_order


# Обновление статуса заказа
@router.put("/{order_id}", response_model=schemas.Order)
async def update_order(order_id: int, order: schemas.OrderBase, db: Session = Depends(get_db)):
    db_order = db.query(models.Order).filter(models.Order.id == order_id).first()
    if db_order is None:
        raise HTTPException(status_code=404, detail="Order not found")

    # Здесь можно добавить логику обновления заказа
    # Пока просто возвращаем существующий заказ
    return db_order


# Удаление заказа
@router.delete("/{order_id}")
async def delete_order(order_id: int, db: Session = Depends(get_db)):
    db_order = db.query(models.Order).filter(models.Order.id == order_id).first()
    if db_order is None:
        raise HTTPException(status_code=404, detail="Order not found")

    db.delete(db_order)
    db.commit()
    return {"message": "Order deleted successfully"}
