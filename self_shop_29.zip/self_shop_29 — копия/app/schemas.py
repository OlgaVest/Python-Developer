# schemas.py
from pydantic import BaseModel, Field, validator, HttpUrl
from typing import List, Optional
from datetime import datetime


# User schemas
class UserBase(BaseModel):
    username: str
    email: str


class UserCreate(UserBase):
    password: str


class User(UserBase):
    id: int
    is_active: bool
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# Category schemas
class CategoryBase(BaseModel):
    name: str


class CategoryCreate(CategoryBase):
    pass


class Category(CategoryBase):
    id: int

    class Config:
        from_attributes = True


# Product schemas
class ProductBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=200, description="Название товара")
    description: Optional[str] = Field(None, max_length=1000, description="Описание товара")
    price: float = Field(..., gt=0, description="Цена товара должна быть больше 0")
    category_id: int
    stock: int = Field(..., ge=0, description="Количество на складе должно быть неотрицательным")

    @validator('name')
    def name_must_not_be_empty(cls, v):
        if not v or not v.strip():
            raise ValueError('Название товара не может быть пустым')
        return v.strip()


class ProductCreate(ProductBase):
    image_url: Optional[HttpUrl] = Field(None, description="URL изображения товара")


class ProductUpdate(ProductBase):
    name: Optional[str] = Field(None, min_length=1, max_length=200)
    price: Optional[float] = Field(None, gt=0)
    stock: Optional[int] = Field(None, ge=0)
    image_url: Optional[HttpUrl] = Field(None, description="URL изображения товара")


# ВАЖНО: Здесь должно быть Product, а не ProductResponse!
class Product(ProductBase):
    id: int
    image_url: Optional[HttpUrl] = None
    is_active: bool
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True


# Order schemas
class OrderItemBase(BaseModel):
    product_id: int
    quantity: int = Field(..., gt=0, description="Количество должно быть больше 0")


class OrderItemCreate(OrderItemBase):
    pass


class OrderItem(OrderItemBase):
    id: int
    order_id: int

    class Config:
        from_attributes = True


class OrderBase(BaseModel):
    pass


class OrderCreate(OrderBase):
    user_id: int
    items: List[OrderItemCreate]


class Order(OrderBase):
    id: int
    user_id: int
    total_price: float
    status: str
    created_at: Optional[datetime] = None
    items: List[OrderItem] = []

    class Config:
        from_attributes = True