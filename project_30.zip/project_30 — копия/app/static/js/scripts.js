"use strict";

document.addEventListener('DOMContentLoaded', () => {
    // Загружаем книги при загрузке страницы
    fetchBooks();

    // Обработка формы создания книги
    const createForm = document.getElementById('create-book-form');
    createForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const book = {
            book_name: document.getElementById('book_name').value,
            author: document.getElementById('author').value,
            genre: document.getElementById('genre').value,
            date_issue: document.getElementById('date_issue').value,
            price: parseFloat(document.getElementById('price').value),
        };

        try {
            const response = await fetch('/api/books/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(book),
            });

            if (response.ok) {
                const newBook = await response.json();
                alert(`Книга создана: ${newBook.book_name} автор ${newBook.author}`);
                createForm.reset();
                fetchBooks(); // Обновляем таблицу
            } else {
                const error = await response.json();
                alert(`Ошибка: ${error.detail}`);
            }
        } catch (error) {
            console.error('Ошибка создания книги:', error);
            alert('Ошибка создания книги');
        }
    });

    // Обработка формы просмотра книги по ID
    const viewForm = document.getElementById('view-book-form');
    viewForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const bookId = document.getElementById('view_book_id').value;

        try {
            const response = await fetch(`/api/books/${bookId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            const resultDiv = document.getElementById('view-book-result');
            if (response.ok) {
                const book = await response.json();
                resultDiv.innerHTML = `
                    <h4>Детали книги:</h4>
                    <p><strong>ID:</strong> ${book.id}</p>
                    <p><strong>Название:</strong> ${book.book_name}</p>
                    <p><strong>Автор:</strong> ${book.author}</p>
                    <p><strong>Жанр:</strong> ${book.genre}</p>
                    <p><strong>Дата выпуска:</strong> ${book.date_issue}</p>
                    <p><strong>Цена:</strong> $${book.price.toFixed(2)}</p>
                `;
            } else {
                const error = await response.json();
                resultDiv.innerHTML = `<p class="text-danger">Ошибка: ${error.detail}</p>`;
            }
        } catch (error) {
            console.error('Ошибка получения книги:', error);
            alert('Ошибка получения книги');
        }
    });

    // Обработка формы обновления книги
    const updateForm = document.getElementById('update-book-form');
    updateForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const bookId = document.getElementById('update_book_id').value;
        const book = {
            book_name: document.getElementById('update_book_name').value || undefined,
            author: document.getElementById('update_author').value || undefined,
            genre: document.getElementById('update_genre').value || undefined,
            date_issue: document.getElementById('update_date_issue').value || undefined,
            price: document.getElementById('update_price').value ? parseFloat(document.getElementById('update_price').value) : undefined,
        };

        // Удаление пустых полей для частичного обновления
        Object.keys(book).forEach(key => {
            if (book[key] === undefined || book[key] === "") {
                delete book[key];
            }
        });

        try {
            const response = await fetch(`/api/books/${bookId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(book),
            });

            if (response.ok) {
                const updated = await response.json();
                alert(`Книга обновлена: ${updated.book_name} автор ${updated.author}`);
                updateForm.reset();
                fetchBooks(); // Обновляем таблицу
            } else {
                const error = await response.json();
                alert(`Ошибка: ${error.detail}`);
            }
        } catch (error) {
            console.error('Ошибка обновления книги:', error);
            alert('Ошибка обновления книги');
        }
    });

    // Обработка формы удаления книги
    const deleteForm = document.getElementById('delete-book-form');
    deleteForm.addEventListener('submit', async (e) {
        e.preventDefault();
        const bookId = document.getElementById('delete_book_id').value;

        if (!confirm(`Вы уверены, что хотите удалить книгу с ID ${bookId}?`)) {
            return;
        }

        try {
            const response = await fetch(`/api/books/${bookId}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            if (response.ok) {
                alert(`Книга удалена`);
                deleteForm.reset();
                fetchBooks(); // Обновляем таблицу
            } else {
                const error = await response.json();
                alert(`Ошибка: ${error.detail}`);
            }
        } catch (error) {
            console.error('Ошибка удаления книги:', error);
            alert('Ошибка удаления книги');
        }
    });

    // === НОВАЯ ФУНКЦИОНАЛЬНОСТЬ ===

    // Фильтрация книг
    const filterForm = document.getElementById('filter-books-form');
    if (filterForm) {
        filterForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const formData = new FormData(filterForm);
            const params = new URLSearchParams();

            for (let [key, value] of formData.entries()) {
                if (value) {
                    params.append(key, value);
                }
            }

            try {
                const response = await fetch(`/api/books?${params.toString()}`);
                if (response.ok) {
                    const books = await response.json();
                    populateBooksTable(books);
                } else {
                    console.error('Ошибка фильтрации книг');
                    alert('Ошибка фильтрации книг');
                }
            } catch (error) {
                console.error('Ошибка фильтрации книг:', error);
                alert('Ошибка фильтрации книг');
            }
        });
    }

    // Сброс фильтра
    const resetFilterBtn = document.getElementById('reset-filter');
    if (resetFilterBtn) {
        resetFilterBtn.addEventListener('click', async () => {
            if (filterForm) {
                filterForm.reset();
            }
            fetchBooks(); // Загружаем все книги
        });
    }

    // Удаление книги через кнопку в таблице
    const booksTable = document.getElementById('books-table');
    if (booksTable) {
        booksTable.addEventListener('click', async (e) => {
            if (e.target.classList.contains('delete-btn')) {
                const bookId = e.target.getAttribute('data-id');
                if (confirm(`Вы уверены, что хотите удалить книгу с ID ${bookId}?`)) {
                    try {
                        const response = await fetch(`/api/books/${bookId}`, {
                            method: 'DELETE',
                            headers: {
                                'Content-Type': 'application/json',
                            },
                        });

                        if (response.ok) {
                            // Удаляем строку из таблицы
                            e.target.closest('tr').remove();
                            alert('Книга удалена успешно!');
                        } else {
                            const error = await response.json();
                            alert(`Ошибка: ${error.detail || 'Не удалось удалить книгу'}`);
                        }
                    } catch (error) {
                        console.error('Ошибка удаления книги:', error);
                        alert('Ошибка удаления книги');
                    }
                }
            }
        });
    }

    // Функция для загрузки и отображения всех книг
    async function fetchBooks() {
        try {
            const response = await fetch('/api/books/', {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            if (response.ok) {
                const books = await response.json();
                populateBooksTable(books);
            } else {
                console.error('Ошибка получения книг');
                alert('Ошибка получения книг');
            }
        } catch (error) {
            console.error('Ошибка получения книг:', error);
            alert('Ошибка получения книг');
        }
    }

    // Функция для заполнения таблицы книг
    function populateBooksTable(books) {
        const tbody = document.querySelector('#books-table tbody');
        tbody.innerHTML = ''; // Очистка существующих строк

        if (books.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7">Книги не найдены</td></tr>';
            return;
        }

        books.forEach(book => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${book.id}</td>
                <td>${book.book_name}</td>
                <td>${book.author}</td>
                <td>${book.genre}</td>
                <td>${book.date_issue}</td>
                <td>$${book.price.toFixed(2)}</td>
                <td>
                    <button class="btn btn-danger btn-sm delete-btn" data-id="${book.id}">Удалить</button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    }
});
