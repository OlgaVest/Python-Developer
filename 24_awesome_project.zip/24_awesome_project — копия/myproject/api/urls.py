# api/urls.py
from django.urls import path
from .views import BookListCreateAPIView, BookDetailAPIView, CategoryListCreateView, CategoryRetrieveUpdateDestroyView # <-- Добавили импорты для Category

urlpatterns = [
    # --- Маршруты для Book ---
    path('books/', BookListCreateAPIView.as_view(), name='book-list-create'),
    path('books/<int:pk>/', BookDetailAPIView.as_view(), name='book-detail'),

    # --- Маршруты для Category ---
    path('categories/', CategoryListCreateView.as_view(), name='category-list-create'),
    path('categories/<int:pk>/', CategoryRetrieveUpdateDestroyView.as_view(), name='category-detail'),
]