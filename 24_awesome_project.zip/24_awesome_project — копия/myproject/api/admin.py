# api/admin.py
from django.contrib import admin
from .models import Book, Category # <-- Добавили импорт Category

# Регистрируем модель Book (если она ещё не зарегистрирована)
@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'published_date', 'isbn')
    list_filter = ('published_date',)
    search_fields = ('title', 'author', 'isbn')

# Регистрируем новую модель Category
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('name', 'description')
    ordering = ('name',) # Сортировка в списке объектов
