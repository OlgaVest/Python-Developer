# api/views.py
from rest_framework import generics
from rest_framework.generics import ListCreateAPIView, RetrieveUpdateDestroyAPIView
from drf_spectacular.utils import extend_schema

from .models import Book, Category
from .serializers import BookSerializer, CategorySerializer


# --- Представления для Book ---

@extend_schema(
    summary="Получение списка книг",
    description="Этот эндпоинт позволяет получить список всех книг в базе данных. "
                "Вы также можете добавить новую книгу с помощью POST-запроса.",
    responses={200: BookSerializer(many=True)}
)
class BookListCreateAPIView(ListCreateAPIView):
    queryset = Book.objects.all()
    serializer_class = BookSerializer


@extend_schema(
    summary="Работа с конкретной книгой",
    description="Позволяет получить информацию о книге, обновить её данные или удалить.",
    responses={
        200: BookSerializer,
        204: None
    }
)
class BookDetailAPIView(RetrieveUpdateDestroyAPIView):
    """
    Представление для работы с отдельной книгой: просмотр, обновление и удаление.
    """
    queryset = Book.objects.all()
    serializer_class = BookSerializer


# --- Представления для Category ---

@extend_schema(
    summary="Получение списка категорий",
    description="Этот эндпоинт позволяет получить список всех категорий. "
                "Вы также можете добавить новую категорию с помощью POST-запроса.",
    responses={200: CategorySerializer(many=True)}
)
class CategoryListCreateView(generics.ListCreateAPIView):
    """
    Представление для получения списка всех категорий (GET)
    и создания новой категории (POST).
    """
    queryset = Category.objects.all()
    serializer_class = CategorySerializer


@extend_schema(
    summary="Работа с конкретной категорией",
    description="Позволяет получить информацию о категории, обновить её данные или удалить.",
    responses={
        200: CategorySerializer,
        204: None
    }
)
class CategoryRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    """
    Представление для получения деталей одной категории (GET),
    её обновления (PUT, PATCH) и удаления (DELETE).
    """
    queryset = Category.objects.all()
    serializer_class = CategorySerializer